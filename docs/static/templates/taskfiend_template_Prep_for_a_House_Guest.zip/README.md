# Prep for a House Guest tweaks

This is a **Task Fiend project template**: a reusable project outline (tasks, subtasks, tags and attachments, without dates or assignees).

## At a Glance

- Exported: Wednesday, September 30, 2026
- Tasks: 5
- Tags: none
- Attachments: 0

## Tasks

- Ask local friends for can't-miss local recommendations
- Ask them what they'd like to see locally
- Create housekeeping project from template
- Confirm dates once desired activities are decided upon
- Request PTO at least two weeks before their arrival

## How to Use It

Upload this zip as-is (don't unzip it) in Task Fiend:

- **Templates → Import Template from Zip** adds it to your template list, so you can create projects from it any time.
- **Projects → Import Template File** creates a new project from it straight away.

The app reads `template.json` and the `attachments/` folder. This README is for people and is ignored on import.
