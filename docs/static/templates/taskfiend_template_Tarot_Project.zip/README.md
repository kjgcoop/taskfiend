# Tarot Project temp

This is a **Task Fiend project template**: a reusable project outline (tasks, subtasks, tags and attachments, without dates or assignees).

## At a Glance

- Exported: Wednesday, September 30, 2026
- Tasks: 78
- Tags: none
- Attachments: 78

## Tasks

- 0. The Fool
- 1. The Magician
- 2. The High Priestess
- 3. The Empress
- 4. The Emperor
- 5. The Hierophant
- 6. The Lovers
- 7. The Chariot
- 8. Strength
- 9. The Hermit
- 10. Wheel of Fortune
- 11. Justice
- 12. The Hanged Man
- 13. Death
- 14. Temperance
- 15. The Devil
- 16. The Tower
- 17. The Star
- 18. The Moon
- 19. The Sun
- 20. Judgement
- 21. The World
- Ace of Cups
- Two of Cups
- Three of Cups
- Four of Cups
- Five of Cups
- Six of Cups
- Seven of Cups
- Eight of Cups
- Nine of Cups
- Ten of Cups
- Page of Cups
- Knight of Cups
- Queen of Cups
- King of Cups
- Ace of Swords
- Two of Swords
- Three of Swords
- Four of Swords
- Five of Swords
- Six of Swords
- Seven of Swords
- Eight of Swords
- Nine of Swords
- Ten of Swords
- Page of Swords
- Knight of Swords
- Queen of Swords
- King of Swords
- Ace of Wands
- Two of Wands
- Three of Wands
- Four of Wands
- Five of Wands
- Six of Wands
- Seven of Wands
- Eight of Wands
- Nine of Wands
- Ten of Wands
- Page of Wands
- Knight of Wands
- Queen of Wands
- King of Wands
- Ace of Pentacles
- Two of Pentacles
- Three of Pentacles
- Four of Pentacles
- Five of Pentacles
- Six of Pentacles
- Seven of Pentacles
- Eight of Pentacles
- Nine of Pentacles
- Ten of Pentacles
- Page of Pentacles
- Knight of Pentacles
- Queen of Pentacles
- King of Pentacles

## How to Use It

Upload this zip as-is (don't unzip it) in Task Fiend:

- **Templates → Import Template from Zip** adds it to your template list, so you can create projects from it any time.
- **Projects → Import Template File** creates a new project from it straight away.

The app reads `template.json` and the `attachments/` folder. This README is for people and is ignored on import.
